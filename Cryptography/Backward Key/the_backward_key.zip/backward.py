#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════╗
║ OBLIVION CORE - ENCRYPTION ENGINE v7.3                   ║
║ CLASSIFIED: VANGUARD INTELLIGENCE DIVISION               ║
╚═══════════════════════════════════════════════════════════╝

WARNING: This module was extracted from OBLIVION's compromised
systems. Analysis suggests it uses non-standard encryption with
unusual properties. Handle with extreme caution.

MISSION OBJECTIVE: Understand how OBLIVION generates encryption
signatures. The AI doesn't decrypt - it forges keys by working
backwards from target outputs.
"""

import sys
import os

# ============================================
# OBLIVION ENCRYPTION CORE
# ============================================

class OblivionCipher:
    """
    OBLIVION's custom encryption engine.
    Uses adaptive key mixing with position-dependent transformations.
    """
    
    def __init__(self, iv=0x5A):
        self.IV = iv  # Initialization Vector
        self._security_layer = True
        self._adaptive_mode = "ENGAGED"
    
    def _obfuscate_key(self, key):
        """Internal key obfuscation - OBLIVION security layer"""
        # Decoy function - doesn't actually do anything critical
        return key
    
    def _validate_input(self, plaintext):
        """Input validation and sanitization"""
        if not isinstance(plaintext, str):
            raise TypeError("OBLIVION CORE: Input must be string")
        if len(plaintext) == 0:
            raise ValueError("OBLIVION CORE: Empty input rejected")
        return True
    
    def encrypt(self, plaintext, key):
        """
        Primary encryption function.
        
        ALGORITHM NOTES (from VanGuard analysis):
        - Uses XOR-based transformation with key
        - Position-dependent modifications applied
        - Final layer applies initialization vector
        
        Each byte processed independently through transformation chain.
        """
        self._validate_input(plaintext)
        
        result = []
        key = self._obfuscate_key(key)
        
        for position, character in enumerate(plaintext):
            # Phase 1: Key mixing
            key_byte = key[position % len(key)]
            phase1 = ord(character) ^ ord(key_byte)
            
            # Phase 2: Position-dependent transformation
            phase2 = (phase1 + position) & 0xFF
            
            # Phase 3: Initialization vector application
            phase3 = phase2 ^ self.IV
            
            result.append(phase3)
        
        return ''.join(f'{byte:02x}' for byte in result)
    
    def _defensive_layer(self):
        """OBLIVION adaptive countermeasures - DO NOT TRIGGER"""
        # Decoy defensive function
        if not self._security_layer:
            return "COUNTERMEASURES ACTIVE"
        return "DORMANT"


# ============================================
# UTILITY FUNCTIONS
# ============================================

def hex_to_bytes(hex_string):
    """Convert hex string to bytes"""
    return bytes.fromhex(hex_string)


def bytes_to_hex(byte_data):
    """Convert bytes to hex string"""
    return byte_data.hex()


def xor_decrypt(encrypted_data, key_signature):
    """
    XOR-based decryption using signature key.
    Used for decrypting OBLIVION data stores.
    """
    key_bytes = hex_to_bytes(key_signature)
    result = []
    
    for i, byte in enumerate(encrypted_data):
        result.append(byte ^ key_bytes[i % len(key_bytes)])
    
    return bytes(result)


# ============================================
# INTERACTIVE MODE
# ============================================

def interactive_mode():
    """Interactive encryption testing"""
    print("""
    ╔═══════════════════════════════════════════════════════════╗
    ║ OBLIVION ENCRYPTION ENGINE - INTERACTIVE MODE            ║
    ╚═══════════════════════════════════════════════════════════╝
    """)
    
    cipher = OblivionCipher()
    
    while True:
        print("\n[OBLIVION CORE] Options:")
        print("  1. Encrypt message")
        print("  2. Decrypt key fragments")
        print("  3. Exit")
        
        choice = input("\n>>> ").strip()
        
        if choice == "1":
            plaintext = input("[INPUT] Plaintext: ").strip()
            key = input("[INPUT] Key: ").strip()
            
            if plaintext and key:
                try:
                    result = cipher.encrypt(plaintext, key)
                    print(f"[OUTPUT] Encrypted: {result}")
                except Exception as e:
                    print(f"[ERROR] {e}")
        
        elif choice == "2":
            signature = input("[INPUT] Signature (hex): ").strip()
            
            try:
                # Try to decrypt key_fragments.enc if it exists
                if os.path.exists('key_fragments.enc'):
                    with open('key_fragments.enc', 'rb') as f:
                        encrypted = f.read()
                    
                    decrypted = xor_decrypt(encrypted, signature)
                    print(f"[OUTPUT] Decrypted: {decrypted.decode('utf-8', errors='ignore')}")
                else:
                    print("[ERROR] key_fragments.enc not found")
            except Exception as e:
                print(f"[ERROR] {e}")
        
        elif choice == "3":
            print("[OBLIVION CORE] Shutting down...")
            break


# ============================================
# MAIN EXECUTION
# ============================================

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "encrypt" and len(sys.argv) >= 4:
            cipher = OblivionCipher()
            plaintext = sys.argv[2]
            key = sys.argv[3]
            result = cipher.encrypt(plaintext, key)
            print(result)
        else:
            print("Usage: python oblivion_core.py encrypt <plaintext> <key>")
    else:
        interactive_mode()